package pro;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/task")
public class task extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        res.setStatus(200);
        res.setContentType("text/html");
        res.getWriter().write("API rate Limiter & Quote Manager is Running");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        String name = req.getParameter("studentName");
        String dept = req.getParameter("studentDept");

        if (name == null || name.trim().isEmpty()
                || dept == null || dept.trim().isEmpty()) {

            res.setStatus(400);
            res.setContentType("text/plain");
            res.getWriter().write("Student details are incomplete");
            return;
        }

        res.setStatus(200);
        res.setContentType("text/plain");
        res.getWriter().write(
                "Student " + name + " from department " + dept + " added successfully"
        );
    }
}